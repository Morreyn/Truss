<?php global $st_options; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

    <!-- favicon -->
    <link rel="icon" type="image/png"
          href="<?php echo esc_url($st_options['favicon'] ['url']); ?>">
    <!-- end favicon -->

    <!-- Apple touch icons -->
    <?php if ($st_options['apple-icon-normal']) { ?>
        <link href="<?php echo esc_url($st_options['apple-icon-1'] ['url']); ?>" rel="apple-touch-icon"/>
    <?php } ?>

    <?php if ($st_options['apple-icon-medium']) { ?>
        <link href="<?php echo esc_url($st_options['apple-icon-2'] ['url']); ?>" rel="apple-touch-icon" sizes="76x76"/>
    <?php } ?>

    <?php if ($st_options['apple-icon-extra-medium']) { ?>
        <link href="<?php echo esc_url($st_options['apple-icon-3'] ['url']); ?>" rel="apple-touch-icon" sizes="120x120"/>
    <?php } ?>

    <?php if ($st_options['apple-icon-large']) { ?>
        <link href="<?php echo esc_url($st_options['apple-icon-4'] ['url']); ?>" rel="apple-touch-icon" sizes="152x152"/>
    <?php } ?>
    <!-- end Apple touch icons -->

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php if ($st_options['preloader']) { ?>
    <div id="st-preloader">
        <div id="pre-status">
            <div class="preload-placeholder"></div>
        </div>
    </div>
<?php } ?><!-- /Preloader -->

<header id="header">
	<div class="container">
		<div id="navigation-wrapper">
			<?php wp_nav_menu( array('container' => false, 'theme_location' => 'main-menu', 'menu_class' => 'menu')); ?>
		</div>
		<div class="menu-mobile"></div>
		<div class="pull-right top-social-search">
			<?php if ($st_options['top-social-section-show']) { ?>
				<div class="top-social text-center">
					<?php if ($st_options['top-facebook-link']) {
						?><a href="<?php echo esc_url($st_options['top-facebook-link']); ?>"><i class="fa fa-facebook"></i></a><?php
					} ?>
					<?php if ($st_options['top-twitter-link']) {
						?><a href="<?php echo esc_url($st_options['top-twitter-link']); ?>"><i class="fa fa-twitter"></i></a><?php
					} ?>
					<?php if ($st_options['top-google-plus-link']) {
						?><a href="<?php echo esc_url($st_options['top-google-plus-link']); ?>"><i class="fa fa-google-plus"></i></a><?php
					} ?>
					<?php if ($st_options['top-youtube-link']) {
						?><a href="<?php echo esc_url($st_options['top-youtube-link']); ?>"><i class="fa fa-youtube"></i></a><?php
					} ?>
					<?php if ($st_options['top-skype-link']) {
						?><a href="<?php echo esc_url($st_options['top-skype-link']); ?>"><i class="fa fa-skype"></i></a><?php
					} ?>
					<?php if ($st_options['top-pinterest-link']) {
						?><a href="<?php echo esc_url($st_options['top-pinterest-link']); ?>"><i class="fa fa-pinterest-p"></i></a><?php
					} ?>
					<?php if ($st_options['top-flickr-link']) {
						?><a href="<?php echo esc_url($st_options['top-flickr-link']); ?>"><i class="fa fa-flickr"></i></a><?php
					} ?>
					<?php if ($st_options['top-linkedin-link']) {
						?><a href="<?php echo esc_url($st_options['top-linkedin-link']); ?>"><i class="fa fa-linkedin"></i></a><?php
					} ?>
					<?php if ($st_options['top-vimeo-link']) {
						?><a href="<?php echo esc_url($st_options['top-vimeo-link']); ?>"><i class="fa fa-vimeo-square"></i></a><?php
					} ?>
					<?php if ($st_options['top-instagram-link']) {
						?><a href="<?php echo esc_url($st_options['top-instagram-link']); ?>"><i class="fa fa-instagram"></i></a><?php
					} ?>
					<?php if ($st_options['top-dribbble-link']) {
						?><a href="<?php echo esc_url($st_options['top-dribbble-link']); ?>"><i class="fa fa-dribbble"></i></a><?php
					} ?>
					<?php if ($st_options['top-behance-link']) {
						?><a href="<?php echo esc_url($st_options['top-behance-link']); ?>"><i class="fa fa-behance"></i></a><?php
					} ?>
					<?php if ($st_options['top-tumblr-link']) {
						?><a href="<?php echo esc_url($st_options['top-tumblr-link']); ?>"><i class="fa fa-tumblr"></i></a><?php
					} ?>
					<?php if ($st_options['top-slideshare-link']) {
						?><a href="<?php echo esc_url($st_options['top-slideshare-link']); ?>"><i class="fa fa-slideshare"></i></a><?php
					} ?>
					<?php if ($st_options['top-soundcloud-link']) {
						?><a href="<?php echo esc_url($st_options['top-soundcloud-link']); ?>"><i class="fa fa-soundcloud"></i></a><?php
					} ?>
					<?php if ($st_options['top-rss-link']) {
						?><a href="<?php echo esc_url($st_options['top-rss-link']); ?>"><i class="fa fa-rss"></i></a><?php
					} ?>
				</div><!-- /Top Social -->
				<?php
			} ?>
			
			<?php if ($st_options['top-search-section-show']) {
				?>
					<div class="top-search">
						<a href="#"><i class="fa fa-search"></i></a>
					</div>
				<?php
			} ?>
			
		</div>
		<?php if ($st_options['top-search-section-show']) {
			?>
				<div class="show-search">
					<?php get_search_form(); ?>
				</div>
			<?php
		} ?>
	</div>
</header>

<div class="logo-carousel">
	<div class="overlay"></div>
	<div class="logo text-center">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url($st_options['logo'] ['url']); ?>" alt="<?php bloginfo( 'name' ); ?>"></a>
	</div>
	<?php if (is_home()) {
		if ($st_options['featured-area-show']) { 
		get_template_part( 'inc/featured_area/featured' );
		} 
	} ?>
</div>

<div id="category-menu">
	<div class="container">
		<div class="category-menu">
			<?php wp_nav_menu( array(
				'container' => false, 
				'theme_location' => 'category-menu', 
				'menu_class' => 'cat-menu'
				)
			); 
			?>
		</div>
		<div class="mobile-cat-menu"></div>
	</div>
</div>


