<?php

    /**
     * ReduxFramework  Config File
     * For full documentation, please visit: https://docs.reduxframework.com
     * */

    if (!class_exists('st_theme_Redux_Framework_config')) {

        class st_theme_Redux_Framework_config
        {

            public $args = array();
            public $sections = array();
            public $theme;
            public $ReduxFramework;

            public function __construct()
            {

                if (!class_exists('ReduxFramework')) {
                    return;
                }

                // This is needed. Bah WordPress bugs.  ;)
                if (TRUE == Redux_Helpers::isTheme(__FILE__)) {
                    $this->initSettings();
                } else {
                    add_action('plugins_loaded', array($this, 'initSettings'), 10);
                }

            }

            public function initSettings()
            {

                // Just for demo purposes. Not needed per say.
                $this->theme = wp_get_theme();

                // Set the default arguments
                $this->setArguments();

                // Set a few help tabs so you can see how it's done
                $this->setHelpTabs();

                // Create the sections and fields
                $this->setSections();

                if (!isset($this->args[ 'opt_name' ])) { // No errors please
                    return;
                }

                // If Redux is running as a plugin, this will remove the demo notice and links
                add_action('redux/loaded', array($this, 'remove_demo'));

                // Function to test the compiler hook and demo CSS output.
                // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
                //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 2);

                // Change the arguments after they've been declared, but before the panel is created
                //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );

                // Change the default value of a field after it's been set, but before it's been useds
                //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );

                // Dynamically add a section. Can be also used to modify sections/fields
                //add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

                $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
            }

            /**
             *
             * This is a test function that will let you see when the compiler hook occurs.
             * It only runs if a field    set with compiler=>true is changed.
             * */
            function compiler_action($options, $css)
            {
                //echo '<h1>The compiler hook has run!';
                //print_r($options); //Option values
                //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

                /*
                  // Demo of how to use the dynamic CSS and write your own static CSS file
                  $filename = dirname(__FILE__) . '/style' . '.css';
                  global $wp_filesystem;
                  if( empty( $wp_filesystem ) ) {
                    require_once( ABSPATH .'/wp-admin/includes/file.php' );
                  WP_Filesystem();
                  }

                  if( $wp_filesystem ) {
                    $wp_filesystem->put_contents(
                        $filename,
                        $css,
                        FS_CHMOD_FILE // predefined mode settings for WP files
                    );
                  }
                 */
            }

            /**
             *
             * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
             * Simply include this function in the child themes functions.php file.
             *
             * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
             * so you must use get_template_directory_uri() if you want to use any of the built in icons
             * */
            function dynamic_section($sections)
            {
                //$sections = array();
                $sections[ ] = array(
                    'title'  => __('Section via hook', 'shaped_theme'),
                    'desc'   => __('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'shaped_theme'),
                    'icon'   => 'el-icon-paper-clip',
                    // Leave this as a blank section, no options just some intro text set above.
                    'fields' => array()
                );

                return $sections;
            }

      

            /**
             *
             * Filter hook for filtering the default value of any given field. Very useful in development mode.
             * */
            function change_defaults($defaults)
            {
                $defaults[ 'str_replace' ] = 'Testing filter hook!';

                return $defaults;
            }

            // Remove the demo link and the notice of integrated demo from the redux-framework plugin
            function remove_demo()
            {

                // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
                if (class_exists('ReduxFrameworkPlugin')) {
                    remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::instance(), 'plugin_metalinks'), NULL, 2);

                    // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                    remove_action('admin_notices', array(ReduxFrameworkPlugin::instance(), 'admin_notices'));
                }
            }

            public function setSections()
            {

                /**
                 * Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
                 * */
                // Background Patterns Reader
                $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
                $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
                $sample_patterns      = array();

                if (is_dir($sample_patterns_path)) :

                    if ($sample_patterns_dir = opendir($sample_patterns_path)) :
                        $sample_patterns = array();

                        while (($sample_patterns_file = readdir($sample_patterns_dir)) !== FALSE) {

                            if (stristr($sample_patterns_file, '.png') !== FALSE || stristr($sample_patterns_file, '.jpg') !== FALSE) {
                                $name               = explode('.', $sample_patterns_file);
                                $name               = str_replace('.' . end($name), '', $sample_patterns_file);
                                $sample_patterns[ ] = array('alt' => $name, 'img' => $sample_patterns_url . $sample_patterns_file);
                            }
                        }
                    endif;
                endif;

                ob_start();

                $ct          = wp_get_theme();
                $this->theme = $ct;
                $item_name   = $this->theme->get('Name');
                $tags        = $this->theme->Tags;
                $screenshot  = $this->theme->get_screenshot();
                $class       = $screenshot ? 'has-screenshot' : '';

                $customize_title = sprintf(__('Customize &#8220;%s&#8221;', 'shaped_theme'), $this->theme->display('Name'));

                ?>
                <div id="current-theme" class="<?php echo esc_attr($class); ?>">
                    <?php if ($screenshot) : ?>
                        <?php if (current_user_can('edit_theme_options')) : ?>
                            <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize"
                               title="<?php echo esc_attr($customize_title); ?>">
                                <img src="<?php echo esc_url($screenshot); ?>"
                                     alt="<?php esc_attr_e('Current theme preview'); ?>"/>
                            </a>
                        <?php endif; ?>
                        <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>"
                             alt="<?php esc_attr_e('Current theme preview'); ?>"/>
                    <?php endif; ?>

                    <h4><?php echo $this->theme->display('Name'); ?></h4>

                    <div>
                        <ul class="theme-info">
                            <li><?php printf(__('By %s', 'shaped_theme'), $this->theme->display('Author')); ?></li>
                            <li><?php printf(__('Version %s', 'shaped_theme'), $this->theme->display('Version')); ?></li>
                            <li><?php echo '<strong>' . __('Tags', 'shaped_theme') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                        </ul>
                        <p class="theme-description"><?php echo $this->theme->display('Description'); ?></p>
                        <?php
                            if ($this->theme->parent()) {
                                printf(' <p class="howto">' . __('This <a href="%1$s">child theme</a> requires its parent theme, %2$s.') . '</p>', __('http://codex.wordpress.org/Child_Themes', 'shaped_theme'), $this->theme->parent()->display('Name'));
                            }
                        ?>

                    </div>
                </div>

                <?php
                $item_info = ob_get_contents();

                ob_end_clean();

                $sampleHTML = '';
                if (file_exists(dirname(__FILE__) . '/info-html.html')) {
                    /** @global WP_Filesystem_Direct $wp_filesystem */
                    global $wp_filesystem;
                    if (empty($wp_filesystem)) {
                        require_once(ABSPATH . '/wp-admin/includes/file.php');
                        WP_Filesystem();
                    }
                    $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
                }

                // ACTUAL DECLARATION OF SECTIONS

                $this->sections[ ] = array(
                    'icon'   => 'el-icon-cogs',
                    'title'  => __('General Settings', 'shaped_theme'),
                    'fields' => array(
                        array(
                            'id'       => 'favicon',
                            'type'     => 'media',
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/favicon/favicon.png' ),
                            'preview'  => 'true',
                            'title'    => __('Favicon.', 'shaped_theme'),
                            'subtitle' => __('Change Favicon from here. <br /> dimension:32px &times; 32px', 'shaped_theme')
                        ),
                        array(
                            'id'       => 'apple-icon-normal',
                            'type'     => 'media',
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/favicon/apple-touch-icon-57-precomposed.png' ),
                            'preview'  => 'true',
                            'title'    => __('Apple iPhone & iPod Icon 57x57', 'shaped_theme'),
                            'subtitle' => __('Add a 57x57 pixels PNG image that will be used for Apple iPhone & iPod.', 'shaped_theme')
                        ),
                        array(
                            'id'       => 'apple-icon-medium',
                            'type'     => 'media',
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/favicon/apple-touch-icon-114-precomposed.png' ),
                            'preview'  => 'true',
                            'title'    => __('Apple iPhone & iPod Icon 76x76', 'shaped_theme'),
                            'subtitle' => __('Add a 114x114 pixels PNG image that will be used for Apple iPhone & iPod', 'shaped_theme')
                        ),
                        array(
                            'id'       => 'apple-icon-extra-medium',
                            'type'     => 'media',
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/favicon/apple-touch-icon-72-precomposed.png' ),
                            'preview'  => 'true',
                            'title'    => __('Apple iPad Icon 120x120', 'shaped_theme'),
                            'subtitle' => __('Add a 72x72 pixels PNG image that will be used for Apple iPad.', 'shaped_theme')
                        ),
                        array(
                            'id'       => 'apple-icon-large',
                            'type'     => 'media',
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/favicon/apple-touch-icon-144-precomposed.png' ),
                            'preview'  => 'true',
                            'title'    => __('Apple iPad Icon 152x152', 'shaped_theme'),
                            'subtitle' => __('Add a 144x144 pixels PNG image that will be used for Apple iPad.', 'shaped_theme')
                        ),

                        array(
                            'id'       => 'preloader',
                            'type'     => 'switch',
                            'title'    => __('Preloader', 'shaped_theme'),
                            'subtitle' => __('Show or Hide Your website Preloader', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'  => TRUE,
                        )

                    )
                );
              

                // header settings
                $this->sections[ ] = array(
                    'icon'   => 'el-icon-slideshare',
                    'title'  => __('Header', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'       => 'logo',
                            'type'     => 'media',
                            'preview'  => 'true',
                            'title'    => __('Site Logo.', 'shaped_theme'),
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/logo.png' ),
                            'subtitle' => __('Change Site logo Size:209x128', 'shaped_theme')
                        ),

                        array(
                            'id'       => 'retina-logo',
                            'type'     => 'media',
                            'preview'  => 'true',
                            'title'    => __('Retina Logo Image (High Density)', 'shaped_theme'),
                            'subtitle' => __('Change Retina logo', 'shaped_theme'),
                            'desc'     => __('<p class="description">Add a image that will be used as the logo in the header section. For the Retina Logo Image the even number of pixels is less important because it will be hardly noticable</p>', 'shaped_theme'),
                        ),

                        // Top Social button

                        array(
                            'id'       => 'top-social-section-show',
                            'type'     => 'switch',
                            'title'    => __('Show Top Social Section', 'shaped_theme'),
                            'subtitle' => __('Show or Hide Social Section in top.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'  => TRUE,
                        ),

                        array(
                            'id'       => 'top-facebook-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Facebook Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Facebook icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-twitter-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Twitter Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Twitter icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-google-plus-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Google Plus Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Google Plus icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-youtube-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Youtube Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Youtube icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-skype-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Skype Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Skype icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-pinterest-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Pinterest Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Pinterest icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-flickr-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Flickr Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Flickr icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-linkedin-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Linkedin Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Linkedin icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-vimeo-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Vimeo Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Vimeo icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-instagram-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Instagram Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Instagram icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-dribbble-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Dribbble Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Dribbble icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-behance-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Behance Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the behance icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-tumblr-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Tumblr Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Tumblr icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-slideshare-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('Slideshare Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the slideshare icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-soundcloud-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('SoundCloud Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the soundcloud icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'top-rss-link',
                            'type'     => 'text',
                            'required' => array('top-social-section-show', '=', '1'),
                            'title'    => __('RSS Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the RSS icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        // Top Search

                        array(
                            'id'       => 'top-search-section-show',
                            'type'     => 'switch',
                            'title'    => __('Show Top Search Section', 'shaped_theme'),
                            'subtitle' => __('Show or Hide Search Section in top.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'  => TRUE,
                        ),

                    )
                );


                // Theme Color
                $this->sections[ ] = array(
                    'icon'   => 'el-icon-website',
                    'title'  => __('Theme Color', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'=>'primary_theme_color',
                            'type' => 'color',
                            'title' => __('Primary Theme Color', 'shaped_theme'), 
                            'subtitle' => __('Pick a primary color for the theme.', 'shaped_theme'),
                            'validate' => 'color',
                            'transparent' => false,
                            'default'  => '#cc9900',
                        ),

                        array(
                            'id'=>'anchor_theme_color',
                            'type' => 'color',
                            'title' => __('Anchor Color', 'shaped_theme'), 
                            'subtitle' => __('Pick a anchor color for the theme.', 'shaped_theme'),
                            'validate' => 'color',
                            'transparent' => false,
                            'default'  => '#E4AB01',
                        ),

                        array(
                            'id'=>'anchor_hover_theme_color',
                            'type' => 'color',
                            'title' => __('Anchor Hover Color', 'shaped_theme'), 
                            'subtitle' => __('Pick a anchor color for the theme.', 'shaped_theme'),
                            'validate' => 'color',
                            'transparent' => false,
                            'default'  => '#cc9900',
                        ),
                        
                    )
                );
              

                // Featured Area
                $this->sections[ ] = array(
                    'icon'   => 'el el-paper-clip',
                    'title'  => __('Featured Area', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'       => 'featured-background',
                            'type'     => 'media',
                            'preview'  => 'true',
                            'title'    => __('Featured Background', 'shaped_theme'),
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/header-bg.jpg' ),
                            'subtitle' => __('Change featured background.', 'shaped_theme')
                        ),

                        array(
                            'id'        => 'featured-overlay',
                            'type'      => 'color_rgba',
                            'title'     => __('Featured overlay color.', 'shaped_theme'),
                            'default'   => array(
                                'color'     => '#fff',
                                'alpha'     => 0.9
                            ),
                            'subtitle' => __('Overlay color (rgba(255, 254, 253, 0.9))', 'shaped_theme')
                        ),

                        array(
                            'id'       => 'featured-area-show',
                            'type'     => 'switch',
                            'title'    => __('Show Featured Area', 'shaped_theme'),
                            'subtitle' => __('Show or Hide Featured Area.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'  => TRUE,
                        ),

                        array(
                            'id'       => 'featured-categorie',
                            'type'     => 'select',
                            'data'     => 'categories',
                            'multi'    => true,
                            'required' => array('featured-area-show', '=', '1'),
                            'title'    => __( 'Select Featured Category', 'shaped_theme' ),
                            'subtitle' => __( 'Select Featured Are Category', 'shaped_theme' ),
                        ),

                        array(
                            'id'       => 'sliders-amount',
                            'type'     => 'text',
                            'required' => array('featured-area-show', '=', '1'),
                            'title'    => __('Amount of Slides', 'shaped_theme'),
                            'subtitle' => __('Insert amount of slides.', 'shaped_theme'),
                            'default'  => "8"
                        ),

                        array(
                            'id'       => 'show-category',
                            'type'     => 'checkbox',
                            'required' => array('featured-area-show', '=', '1'),
                            'title'    => __( 'Show Featured Category', 'shaped_theme' ),
                            'default'  => '1'
                        ),

                    )
                );


                // Post Settings
                $this->sections[ ] = array(
                    'icon'   => 'el-icon-file-edit',
                    'title'  => __('Post Settings', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'       => 'blog-layout',
                            'type'     => 'image_select',
                            'title'    => __('Blog Layout', 'shaped_theme'),
                            'subtitle' => __('Select Blog layout content and sidebar alignment. Choose from Fullwidth, Left sidebar or Right sidebar layout.', 'shaped_theme'),
                            'options'  => array(
                                'no-sidebar'    => array('alt' => '1 Column', 'img' => ReduxFramework::$_url . 'assets/img/1col.png'),
                                'left-sidebar'  => array('alt' => '2 Column Left', 'img' => ReduxFramework::$_url . 'assets/img/2cl.png'),
                                'right-sidebar' => array('alt' => '2 Column Right', 'img' => ReduxFramework::$_url . 'assets/img/2cr.png')
                            ),
                            'default'  => 'right-sidebar'
                        ),

                        array(
                            'id'       => 'blog-page-nav',
                            'type'     => 'switch',
                            'title'    => __('Blog Pagination or Navigation', 'shaped_theme'),
                            'subtitle' => __('Blog pagination style, posts pagination or newer / older posts', 'shaped_theme'),
                            'on'       => __('Pagination', 'shaped_theme'),
                            'off'      => __('Navigation', 'shaped_theme')
                        ),

                        array(
                            'id'        => 'author-name-show',
                            'type'      => 'switch',
                            'title'     => __('Author Name', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Author Name.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'date-show',
                            'type'      => 'switch',
                            'title'     => __('Post Date', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Date.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'comments-show',
                            'type'      => 'switch',
                            'title'     => __('Post Comment', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Comment.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'category-show',
                            'type'      => 'switch',
                            'title'     => __('Post Category', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Category.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'tags-show',
                            'type'      => 'switch',
                            'title'     => __('Post Tags', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Tags.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'st-post-like',
                            'type'      => 'switch',
                            'title'     => __('Post Like', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Post Like.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'share-buttons-show',
                            'type'      => 'switch',
                            'title'     => __('Share Buttons', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Share Buttons.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'      => 'post-social-share-options',
                            'type'    => 'checkbox',
                            'required' => array('share-buttons-show', '=', '1'),
                            'title'   => __( 'Social share options', 'shaped_theme' ),
                            'subtitle'    => __( 'Click on the buttons to disable/enable share buttons.', 'shaped_theme' ),
                            //Must provide key => value pairs for multi checkbox options
                            'options' => array(
                                '1' => 'Facebook',
                                '2' => 'Twitter',
                                '3' => 'Google',
                                '4' => 'Linkedin',
                                '5' => 'Pinterest',
                                '6' => 'Email',
                                '7' => 'StumbleUpon',
                                '8' => 'Digg',
                                '9' => 'Reddit'
                            ),
                            'default' => array(
                                '1' => '1',
                                '2' => '1',
                                '3' => '1',
                                '4' => '1',
                                '5' => '1',
                                '6' => '1',
                                '7' => '1',
                                '8' => '1',
                                '9' => '1'
                            )
                        ),

                        array(
                            'id'        => 'author-box-show',
                            'type'      => 'switch',
                            'title'     => __('Author Box', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide author box.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'next-prev-post-navigation-show',
                            'type'      => 'switch',
                            'title'     => __('Next/Prev Post Navigation', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Next/Prev Post Navigation.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'related-posts-box-show',
                            'type'      => 'switch',
                            'title'     => __('Related Posts Box', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Related Posts Box.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'post-comment-show',
                            'type'      => 'switch',
                            'title'     => __('Post Comment Box', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Post Comment.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),
                        
                    )
                );


                // Page Settings
                $this->sections[ ] = array(
                    'icon'   => 'el el-list-alt',
                    'title'  => __('Page Settings', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'        => 'page-share-buttons-show',
                            'type'      => 'switch',
                            'title'     => __('Share Buttons', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Share Buttons.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'page-comment-show',
                            'type'      => 'switch',
                            'title'     => __('Page Comment Box', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide Page Comment.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),
                        
                    )
                );



                // Instagram
                $this->sections[] = array(
                    'icon'      => 'el el-instagram',
                    'icon_class' => 'el-icon-large',                  
                    'title'     => __('Instagram', 'shaped_theme'),
                    'fields'    => array(

                        array(
                            'id'        => 'instagram-section-show',
                            'type'      => 'switch',
                            'title'     => __('Show instagram', 'shaped_theme'),
                            'subtitle'  => __('Show or Hide instagram carousel section', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'   => true
                        ),

                        array(
                            'id'        => 'instagram-title',
                            'type'      => 'text',
                            'required' => array('instagram-section-show', '=', '1'),
                            'title'     => __('Title', 'shaped_theme'),
                            'default'   => __('Follow on @Instagram', 'shaped_theme'),
                            'subtitle' => __('Instagram carousel section title', 'shaped_theme')
                        ),

                        array(
                            'id'       => 'display_photo_source',
                            'type'     => 'select',
                            'required' => array('instagram-section-show', '=', '1'),
                            'title'    => __( 'Instagram source', 'shaped_theme' ),
                            'subtitle' => __( 'Select where form instagram photos will display', 'shaped_theme' ),
                            'options'  => array(
                                '1' => 'Display tagged photos',
                                '2' => 'Display from my account'
                            ),
                            'default'  => '1'
                        ),

                        array(
                            'id'       => 'tag_name',
                            'type'     => 'text',
                            'title'    => __( 'Tag name', 'shaped_theme' ),
                            'subtitle' => __( 'Type from which tag instagram photos will show.', 'shaped_theme' ),
                            'mode'     => 'text',
                            'required' => array( 'display_photo_source', "=", '1' ),
                        ),

                        array(
                            'id'        => 'instagram-user-id',
                            'type'      => 'text',
                            'required' => array('display_photo_source', '=', '2'),
                            'title'     => __('User ID', 'shaped_theme'),
                            'subtitle' => __('Don\'t know your user ID? <a target="_blank" href="https://instagram.com/oauth/authorize/?client_id=467ede5a6b9b48ae8e03f4e2582aeeb3&redirect_uri=http://instafeedjs.com&response_type=token">Click here (Opens in new tab)</a> & sign in with your account, you will get your account user ID.', 'shaped_theme')
                        ),

                        array(
                            'id'        => 'instagram-access-token',
                            'type'      => 'text',
                            'required' => array('instagram-section-show', '=', '1'),
                            'title'     => __('AccessToken', 'shaped_theme'),
                            'subtitle' => __('Don\'t know your access token? <a target="_blank" href="https://instagram.com/oauth/authorize/?client_id=467ede5a6b9b48ae8e03f4e2582aeeb3&redirect_uri=http://instafeedjs.com&response_type=token">Click here (Opens in new tab)</a> & sign in with your account, you will get your account access token.', 'shaped_theme')
                        ),

                        array(
                            'id'        => 'instagram-slides-amount',
                            'type'      => 'text',
                            'required' => array('instagram-section-show', '=', '1'),
                            'title'     => __('Amount of Slides', 'shaped_theme'),
                            'default'     => ('13'),
                            'subtitle' => __('Insert amount of slides.', 'shaped_theme')
                        )


                    )
                );



                // footer settings
                $this->sections[ ] = array(
                    'icon'   => 'el-icon-photo',
                    'title'  => __('Footer', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'        =>'footer-logo',
                            'url'       => false,
                            'type'      => 'media', 
                            'title'     => __('Footer Logo', 'shaped_theme'),
                            'default'   => array( 'url' => get_template_directory_uri() .'/images/footer-logo.png' ),
                            'subtitle'  => __('Upload your footer logo Size: 180x110.', 'shaped_theme'),
                        ),

                        // Footer Social button

                        array(
                            'id'       => 'footer-social-section-show',
                            'type'     => 'switch',
                            'title'    => __('Show Footer Social Section', 'shaped_theme'),
                            'subtitle' => __('Show or Hide Social Section in footer.', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'  => TRUE,
                        ),

                        array(
                            'id'       => 'footer-facebook-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Facebook Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Facebook icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-twitter-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Twitter Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Twitter icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-google-plus-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Google Plus Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Google Plus icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-youtube-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Youtube Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Youtube icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-skype-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Skype Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Skype icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-pinterest-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Pinterest Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Pinterest icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-flickr-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Flickr Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Flickr icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-linkedin-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Linkedin Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Linkedin icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-vimeo-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Vimeo Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Vimeo icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-instagram-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Instagram Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Instagram icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-dribbble-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Dribbble Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Dribbble icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-behance-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Behance Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the behance icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-tumblr-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Tumblr Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the Tumblr icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-slideshare-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('Slideshare Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the slideshare icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-soundcloud-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('SoundCloud Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the soundcloud icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'footer-rss-link',
                            'type'     => 'text',
                            'required' => array('footer-social-section-show', '=', '1'),
                            'title'    => __('RSS Link', 'shaped_theme'),
                            'subtitle' => __('Insert your custom link to show the RSS icon. Leave blank to hide icon.', 'shaped_theme'),
                            'default'  => ""
                        ),

                        array(
                            'id'       => 'to-top',
                            'type'     => 'switch',
                            'title'    => __('Back to top', 'shaped_theme'),
                            'subtitle' => __('Show or Hide backtop top option from footer', 'shaped_theme'),
                            'on'       => 'Show',
                            'off'      => 'Hide',
                            'default'  => TRUE,
                        ), 

                        array(
                            'id'       => 'footer-text',
                            'type'     => 'editor',
                            'title'    => __('Footer Copyright Text', 'shaped_theme'),
                            'subtitle' => __('Write footer copyright text here.', 'shaped_theme'),
                            'default'  => __('&copy; 2015 <a href="#">Shaped</a>. All rights reserved. Made with <i class="fa fa-heart"></i> by <a href="#" target="_blank">ShapedTheme</a>', 'shaped_theme')
                        )
                    )
                );



                // footer settings
                $this->sections[ ] = array(
                    'icon'   => 'el-icon-edit',
                    'title'  => __('Custom CSS/JS', 'shaped_theme'),
                    'fields' => array(

                        array(
                            'id'       => 'st-custom-css',
                            'type'     => 'ace_editor',
                            'title'    => __( 'CSS Code', 'shaped_theme' ),
                            'subtitle' => __( 'Paste your CSS code here.', 'shaped_theme' ),
                            'mode'     => 'css',
                            'theme'    => 'monokai',
                            'default'  => "#header{\n   margin: 0 auto;\n}"
                        ),
                        array(
                            'id'       => 'st-custom-js',
                            'type'     => 'ace_editor',
                            'title'    => __( 'JS Code', 'shaped_theme' ),
                            'subtitle' => __( 'Paste your JS code here.', 'shaped_theme' ),
                            'mode'     => 'javascript',
                            'theme'    => 'chrome',
                            'default'  => "jQuery(document).ready(function(){\n\n});"
                        )

                    )
                );


            }

            public function setHelpTabs()
            {

                // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
                $this->args[ 'help_tabs' ][ ] = array(
                    'id'      => 'redux-help-tab-1',
                    'title'   => __('Theme Information 1', 'shaped_theme'),
                    'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'shaped_theme')
                );

                $this->args[ 'help_tabs' ][ ] = array(
                    'id'      => 'redux-help-tab-2',
                    'title'   => __('Theme Information 2', 'shaped_theme'),
                    'content' => __('<p>This is the tab content, HTML is allowed.</p>', 'shaped_theme')
                );

                // Set the help sidebar
                $this->args[ 'help_sidebar' ] = __('<p>This is the sidebar content, HTML is allowed.</p>', 'shaped_theme');
            }

            /**
             *
             * All the possible arguments for Redux.
             * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
             * */
            public function setArguments()
            {

                $theme = wp_get_theme(); // For use with some settings. Not necessary.

                // icon used from http://shoestrap.yoyo.io/elusive-icons/

                $this->args = array(
                    'opt_name'           => 'st_options',
                    'page_priority'      => '40',
                    'allow_sub_menu'     => '1',
                    'admin_bar'          => FALSE,
                    'customizer'         => '1',
                    'page_parent'        => 'themes.php',
                    'footer_credit'      => 'Options of ' . $this->theme->get('Name'),
                    'default_mark'       => '*',
                    'footer_text'        => '',
                    'hint-icon'          => 'el-icon-question-sign',
                    'icon_position'      => 'right',
                    'icon_color'         => 'lightgray',
                    'icon_size'          => 'normal',
                    'tip_style_color'    => 'light',
                    'tip_position_my'    => 'top left',
                    'tip_position_at'    => 'bottom right',
                    'tip_show_duration'  => '500',
                    'tip_show_event'     =>
                        array(
                            0 => 'mouseover',
                        ),
                    'tip_hide_duration'  => '500',
                    'tip_hide_event'     =>
                        array(
                            0 => 'mouseleave',
                            1 => 'unfocus',
                        ),
                    'intro_text'         => '',
                    'menu_title'         => __('Theme Options', 'shaped_theme'),
                    'menu_type'          => 'menu',
                    'output'             => '1',
                    'output_tag'         => '1',
                    'page_icon'          => 'icon-themes',
                    // 'page_parent_post_type' => 'your_post_type',
                    'page_permissions'   => 'manage_options',
                    'page_slug'          => '_options',
                    'page_title'         => __('Theme Options', 'shaped_theme'),
                    'save_defaults'      => '1',
                    'show_import_export' => '1',
                    'update_notice'      => '1',
                    // Set a different name for your global variable other than the opt_name
                    'dev_mode'             => false,
                );

                $theme                           = wp_get_theme(); // For use with some settings. Not necessary.
                $this->args[ "display_name" ]    = $theme->get("Name");
                $this->args[ "display_version" ] = $theme->get("Version");

                // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.

                /*

                            $this->args['share_icons'][] = array(
                                'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
                                'title' => 'Visit us on GitHub',
                                'icon'  => 'el-icon-github'
                                //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
                            );
                            $this->args['share_icons'][] = array(
                                'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
                                'title' => 'Like us on Facebook',
                                'icon'  => 'el-icon-facebook'
                            );
                            $this->args['share_icons'][] = array(
                                'url'   => 'http://twitter.com/reduxframework',
                                'title' => 'Follow us on Twitter',
                                'icon'  => 'el-icon-twitter'
                            );
                            $this->args['share_icons'][] = array(
                                'url'   => 'http://www.linkedin.com/company/redux-framework',
                                'title' => 'Find us on LinkedIn',
                                'icon'  => 'el-icon-linkedin'
                            );

                */


            }

        }

        global $reduxConfig;
        $reduxConfig = new st_theme_Redux_Framework_config();
    }

    /**
     * Custom function for the callback referenced above
     */
    if (!function_exists('st_theme_my_custom_field')):
        function st_theme_my_custom_field($field, $value)
        {
            print_r($field);
            echo '<br/>';
            print_r($value);
        }
    endif;

    /**
     * Custom function for the callback validation referenced above
     * */
    if (!function_exists('st_theme_validate_callback_function')):
        function st_theme_validate_callback_function($field, $value, $existing_value)
        {
            $error = FALSE;
            $value = 'just testing';

            /*
              do your validation

              if(something) {
                $value = $value;
              } elseif(something else) {
                $error = true;
                $value = $existing_value;
                $field['msg'] = 'your custom error message';
              }
             */

            $return[ 'value' ] = $value;
            if ($error == TRUE) {
                $return[ 'error' ] = $field;
            }
            return $return;
        }
    endif;
