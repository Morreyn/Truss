<?php get_header(); ?>
<?php global $st_options; ?>

<div class="st-content">
    <div class="container">
        <div class="row">
            <?php
                $sidebar = is_null($st_options['blog-layout']) ? 'right-sidebar' : $st_options['blog-layout'];

                $grid_class = 'col-md-12';

                if ($sidebar == 'right-sidebar') {

                    $grid_class = (is_active_sidebar('st-blog-sidebar'))
                        ? 'col-md-9 col-sm-8 margin-right-40'
                        : $grid_class;

                } elseif ($sidebar == 'left-sidebar') {
                    $grid_class = (is_active_sidebar('st-blog-sidebar'))
                        ? 'col-md-9 col-md-push-3 col-sm-8 col-sm-push-4 margin-left-40'
                        : $grid_class;
                }
            ?>
            <div class="<?php echo esc_attr($grid_class); ?>">
                <div id="primary" class="content-area">
                    <main id="main" class="site-main" role="main">

                        <?php if (have_posts()) :
                            while (have_posts()) :
                                the_post();
                                ?>

                                <?php get_template_part( 'inc/post-format/single', get_post_format() ); ?>

                                <?php if ($st_options['author-box-show']) {
                                    get_template_part( 'user-profile' );
                                } ?>

                                <?php if ($st_options['next-prev-post-navigation-show']) {
                                    st_post_navigation();
                                } ?>

                                <?php if ($st_options['related-posts-box-show']) {
                                    get_template_part( 'related-post' );
                                } ?>

                                <?php
                                if ($st_options['post-comment-show']) {
                                    // If comments are open or we have at least one comment, load up the comment template
                                    if (comments_open() || '0' != get_comments_number()) {
                                        comments_template();
                                    }
                                }
                                ?>

                                <?php
                                    // don't-delete 
                                    $count_post = get_post_meta( $post->ID, 'post_views_count', true);
                                    
                                    if( $count_post == 'post_views_count'){
                                        $count_post = 0;
                                        delete_post_meta( $post->ID, 'post_views_count');
                                        add_post_meta( $post->ID, 'post_views_count', $count_post);
                                    }
                                    else
                                    {
                                        $count_post = (int)$count_post + 1;
                                        update_post_meta( $post->ID, 'post_views_count', $count_post);
                                        
                                    }
                                ?>

                            <?php endwhile; // end of the loop. ?>

                        <?php else : ?>

                            <?php get_template_part('content', 'none'); ?>

                        <?php endif; ?>
                    </main> <!-- /.site-main -->
                </div>  <!-- /.content-area -->
            </div> <!-- /col -->

            <!-- Blogsidebar -->
            <?php get_sidebar(); ?>

        </div> <!-- /.row -->
    </div> <!-- /.container -->
</div>
<?php get_footer(); ?>