<?php get_header(); ?>
<div class="st-content">
    <div class="container">
        <div class="row">
        <div class="col-sm-12">
			<div id="primary" class="content-area">
				<main id="main" class="site-main" role="main">

					<section class="error-404 not-found text-center">
						<h1 class="404">404</h1>
						<p class="lead">Sorry, we could not found the page you are looking for!<br>Please search using the below form again.</p>

						<div class="row">
							<div class="col-sm-4 col-sm-offset-4">
								<?php get_search_form(); ?>
							</div>
						</div>
						
					</section><!-- .error-404 -->

				</main><!-- #main -->
			</div><!-- #primary -->
		</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
