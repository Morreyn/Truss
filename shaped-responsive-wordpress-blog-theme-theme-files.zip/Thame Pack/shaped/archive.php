<?php get_header(); ?>
<?php global $st_options; ?>

	<div class="st-content">
		<div class="container">
			<div class="row">
				<?php
                    $sidebar = is_null($st_options['blog-layout']) ? 'right-sidebar' : $st_options['blog-layout'];

                    $grid_class = 'col-md-12';

                    if ($sidebar == 'right-sidebar') {

                        $grid_class = (is_active_sidebar('st-blog-sidebar'))
                            ? 'col-md-9 col-sm-8 margin-right-40'
                            : $grid_class;

                    } elseif ($sidebar == 'left-sidebar') {
                        $grid_class = (is_active_sidebar('st-blog-sidebar'))
                            ? 'col-md-9 col-md-push-3 col-sm-8 col-sm-push-4 margin-left-40'
                            : $grid_class;
                    }
                ?>

				<div class="<?php echo $grid_class ?>">

					<div id="primary" class="content-area">
						<main id="main" class="site-main" role="main">

						<?php if ( have_posts() ) : ?>

							<header class="search-header">
								<?php
									st_archive_title( '<div class="search-title">', '</div>' );
									the_archive_description( '<div class="taxonomy-description">', '</div>' );
								?>
							</header><!-- .page-header -->

							<?php while ( have_posts() ) : the_post(); ?>

								<?php
									/* Include the Post-Format-specific template for the content.
									 * If you want to override this in a child theme, then include a file
									 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
									 */
									get_template_part( 'inc/post-format/content', get_post_format() );
								?>

							<?php endwhile; ?>

							<?php

							 // Posts Pagination
                                if ($st_options['blog-page-nav']) {
                                    st_posts_pagination();
                                } else {
                                    st_posts_navigation();
                                }

							?>

						<?php else : ?>

							<?php get_template_part( 'content', 'none' ); ?>

						<?php endif; ?>

						</main><!-- #main -->
					</div><!-- #primary -->

				</div> <!-- /col -->
				<!-- Blogsidebar -->			
				<?php get_sidebar(); ?>
			</div> <!-- /.row -->
		</div> <!-- /.container -->
	</div> <!-- /.st-content -->

<?php get_footer(); ?>
