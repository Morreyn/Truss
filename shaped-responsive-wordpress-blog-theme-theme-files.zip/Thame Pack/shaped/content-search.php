
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
    </header><!-- .entry-header -->
    
    <?php if ( 'post' == get_post_type() ) : ?>
    <div class="entry-meta">
        <?php st_posted_on(); ?>
    </div><!-- .entry-meta -->
    <?php endif; ?>
        
    <?php if (has_post_thumbnail()) { ?>
        <div class="thumbnails">
            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail('post-thumbnails', array('class' => 'post-thumbnail img-responsive')); ?></a>
        </div>
    <?php } ?>

    <div class="entry-content">
        <?php the_content(__('<br><br><span class="read-more-button">Read more <i class="fa fa-long-arrow-right"></i></span>', 'shaped_theme')); ?>

        <?php
            wp_link_pages( array(
                'before' => '<div class="page-links">' . __( 'Pages:', 'shaped_theme' ),
                'after'  => '</div>',
            ) );
        ?>
    </div><!-- .entry-content -->

</article><!-- #post-## -->

<div class="post-border"></div>