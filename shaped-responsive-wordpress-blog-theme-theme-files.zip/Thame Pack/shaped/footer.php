<?php global $st_options; 
	$user_id = $st_options['instagram-user-id'];
	$access_token = $st_options['instagram-access-token'];
	$slides_limit = $st_options['instagram-slides-amount'];
	$tag_name = $st_options['tag_name'];
?>
<footer id="footer">
	
	<?php if ($st_options['instagram-section-show']) { ?>
		<div class="instafeed-carousel">
			<?php if ($st_options['instagram-title']) { ?>
				<h3 class="text-center instafeed-title"><?php echo esc_attr($st_options['instagram-title']); ?></h3>
			<?php } ?>
			<div id="instafeed"></div>
		</div>
	<?php } ?>

	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<?php if ($st_options['footer-logo']) {
					?>
						<div class="footer-logo text-center">
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url($st_options['footer-logo'] ['url']); ?>"></a>
						</div><!-- /Footer Logo -->
					<?php
				}
				 ?>
				
				<?php if ($st_options['footer-social-section-show']) {
					?>
					<div class="footer-social text-center">
						<?php if ($st_options['footer-facebook-link']) {
							?><a href="<?php echo esc_url($st_options['footer-facebook-link']); ?>" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a><?php
						} ?>
						<?php if ($st_options['footer-twitter-link']) {
							?><a href="<?php echo esc_url($st_options['footer-twitter-link']); ?>" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a><?php
						} ?>
						<?php if ($st_options['footer-google-plus-link']) {
							?><a href="<?php echo esc_url($st_options['footer-google-plus-link']); ?>" data-toggle="tooltip" data-placement="top" title="Google +"><i class="fa fa-google-plus"></i></a><?php
						} ?>
						<?php if ($st_options['footer-youtube-link']) {
							?><a href="<?php echo esc_url($st_options['footer-youtube-link']); ?>" data-toggle="tooltip" data-placement="top" title="Youtube"><i class="fa fa-youtube"></i></a><?php
						} ?>
						<?php if ($st_options['footer-skype-link']) {
							?><a href="<?php echo esc_url($st_options['footer-skype-link']); ?>" data-toggle="tooltip" data-placement="top" title="Skype"><i class="fa fa-skype"></i></a><?php
						} ?>
						<?php if ($st_options['footer-pinterest-link']) {
							?><a href="<?php echo esc_url($st_options['footer-pinterest-link']); ?>" data-toggle="tooltip" data-placement="top" title="Pinterest"><i class="fa fa-pinterest-p"></i></a><?php
						} ?>
						<?php if ($st_options['footer-flickr-link']) {
							?><a href="<?php echo esc_url($st_options['footer-flickr-link']); ?>" data-toggle="tooltip" data-placement="top" title="Flickr"><i class="fa fa-flickr"></i></a><?php
						} ?>
						<?php if ($st_options['footer-linkedin-link']) {
							?><a href="<?php echo esc_url($st_options['footer-linkedin-link']); ?>" data-toggle="tooltip" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a><?php
						} ?>
						<?php if ($st_options['footer-vimeo-link']) {
							?><a href="<?php echo esc_url($st_options['footer-vimeo-link']); ?>" data-toggle="tooltip" data-placement="top" title="Vimeo"><i class="fa fa-vimeo-square"></i></a><?php
						} ?>
						<?php if ($st_options['footer-instagram-link']) {
							?><a href="<?php echo esc_url($st_options['footer-instagram-link']); ?>" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="fa fa-instagram"></i></a><?php
						} ?>
						<?php if ($st_options['footer-dribbble-link']) {
							?><a href="<?php echo esc_url($st_options['footer-dribbble-link']); ?>" data-toggle="tooltip" data-placement="top" title="Dribbble"><i class="fa fa-dribbble"></i></a><?php
						} ?>
						<?php if ($st_options['footer-behance-link']) {
							?><a href="<?php echo esc_url($st_options['footer-behance-link']); ?>" data-toggle="tooltip" data-placement="top" title="Behance"><i class="fa fa-behance"></i></a><?php
						} ?>
						<?php if ($st_options['footer-tumblr-link']) {
							?><a href="<?php echo esc_url($st_options['footer-tumblr-link']); ?>" data-toggle="tooltip" data-placement="top" title="Tumblr"><i class="fa fa-tumblr"></i></a><?php
						} ?>
						<?php if ($st_options['footer-slideshare-link']) {
							?><a href="<?php echo esc_url($st_options['footer-slideshare-link']); ?>" data-toggle="tooltip" data-placement="top" title="Slideshare"><i class="fa fa-slideshare"></i></a><?php
						} ?>
						<?php if ($st_options['footer-soundcloud-link']) {
							?><a href="<?php echo esc_url($st_options['footer-soundcloud-link']); ?>" data-toggle="tooltip" data-placement="top" title="Soundcloud"><i class="fa fa-soundcloud"></i></a><?php
						} ?>
						<?php if ($st_options['footer-rss-link']) {
							?><a href="<?php echo esc_url($st_options['footer-rss-link']); ?>" data-toggle="tooltip" data-placement="top" title="RSS"><i class="fa fa-rss"></i></a><?php
						} ?>
					</div><!-- /Footer Social -->
					<?php
				} ?>

				<div class="copy-right-text text-center">
					<p><?php echo $st_options['footer-text']; ?></p>
				</div><!-- /Copyright Text -->
			</div>
		</div>
	</div>

</footer><!-- /#Footer -->

<?php if ($st_options['to-top']) { ?>
    <div class="scroll-up">
        <a href="#"><i class="fa fa-long-arrow-up"></i></a>
    </div>
<?php } ?><!-- Scroll Up -->

<?php wp_footer(); ?>

<script type="text/javascript">
	jQuery(function($){

	'use strict';

	  (function () {
	    var feed = new Instafeed({
            <?php if($st_options['display_photo_source'] == '2'): ?>
            get: 'user',
            userId: <?php echo esc_attr($user_id); ?>,
            <?php else : ?>
            get: 'tagged',
            tagName: '<?php echo esc_attr($st_options['tag_name']); ?>',
            <?php endif; ?>
	        resolution: 'standard_resolution',
	        accessToken: '<?php echo esc_attr($access_token); ?>',
	        template: '<li class="item"><a class="animation" href="{{link}}"><img class="img-responsive" src="{{image}}" /></a></li>',
	        limit: <?php echo esc_attr($slides_limit) ?>,
	        target: 'instafeed',
	        after: function() {
	            $('#instafeed').owlCarousel({
	              items : 6,
	              itemsDesktop : [1199,3],
	              itemsDesktopSmall : [979,3],
	              navigation : true,
	              navigationText : ["<i class='fa fa-long-arrow-left'></i>","<i class='fa fa-long-arrow-right'></i>"],
	              pagination : false
	            });
	        }
	    });
	    feed.run();
	  }());

});
</script>

</body>
</html>
