<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
    <div>
		<input type="text" placeholder="<?php _e('Search and hit enter...', 'shaped_theme'); ?>" name="s" id="s" />
	 </div>
</form>