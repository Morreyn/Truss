﻿jQuery(function($){

'use strict';


/* === Tooltip === */

  (function () {
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
  }());


/* === Preloader === */

  (function () {
      $(window).load(function() {
          $('#pre-status').fadeOut();
          $('#st-preloader').delay(350).fadeOut('slow');
      });
  }());


/* === Back To Top === */

  (function () {
      $(window).scroll(function() {
          if ($(this).scrollTop() > 100) {
              $('.scroll-up').fadeIn();
          } else {
              $('.scroll-up').fadeOut();
          }
      });
      $('.scroll-up a').click(function(){
            $('html, body').animate({scrollTop : 0},800);
            return false;
        });
  }());


/* === Menu === */

  (function () {
    $('#header .menu').slicknav({
      prependTo:'.menu-mobile',
      label:''
    })

    $('#category-menu .cat-menu').slicknav({
      prependTo:'.mobile-cat-menu',
      label:''
    })
  }());


/* === Search === */

  (function () {
    $('.top-search a').on('click', function ( e ) {
    e.preventDefault();
      $('.show-search').slideToggle('fast');
      $('.top-search a').toggleClass('sactive');
    });
  }());


/* === Featured Area === */

  (function () {
    $("#post-carousel").owlCarousel({
        items : 4,
        itemsDesktop : [1199,3],
        itemsDesktopSmall : [979,3]
    });
  }());



/* === Fitvids js === */
  (function () {
      $(".wpb_wrapper").fitVids();
      $(".entry-content").fitVids();
      $(".entry-video").fitVids();
  }()); 


/* === Magnific Popup js === */
  (function () {

    $('.gallery-item').magnificPopup({ 
      delegate: 'a',
      type: 'image',
      // other options
      closeOnContentClick: false,
      closeBtnInside: false,
      mainClass: 'mfp-with-zoom mfp-img-mobile',

      gallery: {
        enabled: true
      },
      zoom: {
        enabled: true,
        duration: 300, // don't foget to change the duration also in CSS
        opener: function(element) {
          return element.find('img');
        }
      }

    });

  }()); 
	
});