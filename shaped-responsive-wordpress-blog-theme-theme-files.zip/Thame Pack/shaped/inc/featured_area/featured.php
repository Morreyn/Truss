<?php global $st_options; 
	$featured_categories = $st_options['featured-categorie'];
	$sliders_amount = $st_options['sliders-amount'];
    $defaultThumb = get_template_directory_uri().'/images/c-no-thumb.jpg';

?>

	<div id="post-carousel">
	
		<?php $feat_query = new WP_Query( array( 'cat' => $featured_categories, 'showposts' => $sliders_amount ) ); ?>
		<?php if ($feat_query->have_posts()) : while ($feat_query->have_posts()) : $feat_query->the_post(); ?>
			<div class="item">
				<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
				<?php 
				if (has_post_thumbnail()) {
				 	the_post_thumbnail('featured-image', array('class' => 'featured-thumb'));
				 } else {
				 	echo "<img src='".$defaultThumb."' class='img-responsive related-thumb'>";
				 }
				 ?></a>
				<div class="overlay"></div>
				<div class="post-title">
					<h3><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words( get_the_title(), 4 ); ?></a></h3>
					<?php if ($st_options['show-category']) { ?>
						<?php the_category( '', '', '' ); ?>
					<?php } ?>
				</div>
			</div>
		<?php endwhile; endif; ?>

	</div><!-- /post-carousel -->