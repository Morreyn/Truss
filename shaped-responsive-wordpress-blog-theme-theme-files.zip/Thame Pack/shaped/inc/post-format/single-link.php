<?php global $st_options; ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
    </header><!-- .entry-header -->

    <?php if ( 'post' == get_post_type() ) : ?>
    <div class="entry-meta">
        <?php st_posted_on(); ?>
    </div><!-- .entry-meta -->
    <?php endif; ?>
    
    <?php if (rwmb_meta('st_link')) { ?>
        <div class="thumbnails" style="background-image:url(<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ); ?>);   background-size: cover; position: relative;">
            <div class="post-link-overlay"></div>
            <div class="entry-link">
                <a href="<?php echo esc_url(rwmb_meta( 'st_link' )); ?>"><?php echo esc_url(rwmb_meta( 'st_link' )); ?></a>
            </div>
        </div>
    <?php } ?>

    <div class="entry-content">
        <?php the_content(); ?>
    </div> <!-- //.entry-content -->

</article> <!--/#post-->

<?php if ($st_options['tags-show']) { ?>
    <div class="entry-tags"><?php the_tags('', '', ''); ?></div>
<?php } ?>

<br>

<?php if ($st_options['share-buttons-show']) { 
    get_template_part( 'inc/post-format/social-buttons' );
 } ?>

<?php if ($st_options['st-post-like']) { ?>
    <div class="pull-right st-post-like"><?php echo getPostLikeLink( get_the_ID() ); ?></div>
<?php } ?>
<div class="single-post-border"></div>