
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="thumbnails" style="background-image:url(<?php echo wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) ); ?>);   background-size: cover; position: relative; margin-bottom: 40px;">
        <div class="post-link-overlay"></div>
        <div class="entry-qoute">
            <blockquote>
                <p><?php echo esc_attr(rwmb_meta( 'st_qoute' )); ?></p>
                <small><?php echo esc_attr(rwmb_meta( 'st_qoute_author' )); ?></small>
            </blockquote>
        </div>
    </div>
</article> <!--/#post -->

<div class="post-border"></div>