
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
    </header> <!--/.entry-header -->

    <?php if ( 'post' == get_post_type() ) : ?>
    <div class="entry-meta">
        <?php st_posted_on(); ?>
    </div><!-- .entry-meta -->
    <?php endif; ?>
        
    <?php $slides = rwmb_meta('st_gallery_images','type=image_advanced'); ?>
    <?php $count = count($slides); ?>
    <?php if($count > 0): ?>
        <div class="thumbnails">
            <div id="blog-gallery-slider" class="carousel slide" data-ride="carousel">

                <!-- Wrapper for slides -->
                <div class="carousel-inner">

                    <?php $slide_no = 1; ?>

                    <?php foreach( $slides as $slide ): ?>
                        <div class="item <?php if($slide_no == 1){ echo 'active'; }; ?>">
                            <?php $images = wp_get_attachment_image_src( $slide['ID'], 'blog-thumb' ); ?>
                            <img src="<?php echo $images[0]; ?>" alt="<?php the_title(); ?>">
                        </div>
                        <?php $slide_no++ ?>
                    <?php endforeach; ?>

                </div>

                <!-- Controls -->
                <a class="left carousel-control" href="#blog-gallery-slider" data-slide="prev">
                <i class="fa fa-long-arrow-left"></i>
                </a>
                <a class="right carousel-control" href="#blog-gallery-slider" data-slide="next">
                <i class="fa fa-long-arrow-right"></i>
                </a>
            </div>
        </div>
    <?php endif; ?>


    <div class="entry-content">
        <?php the_content(__('<br><br><span class="read-more-button">Read more <i class="fa fa-long-arrow-right"></i></span>', 'shaped_theme')); ?>

        <?php
            wp_link_pages( array(
                'before' => '<div class="page-links">' . __( 'Pages:', 'shaped_theme' ),
                'after'  => '</div>',
            ) );
        ?>
    </div><!-- .entry-content -->

</article><!-- #post-## -->

<div class="post-border"></div>