
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
    </header><!-- .entry-header -->

    <?php if ( 'post' == get_post_type() ) : ?>
    <div class="entry-meta">
        <?php st_posted_on(); ?>
    </div><!-- .entry-meta -->
    <?php endif; ?>

    <?php if (rwmb_meta( 'st_audio_code' )) { ?>
        <div class="thumbnails">
            <div class="entry-audio">
                <?php echo rwmb_meta( 'st_audio_code' ); ?>
            </div> <!--/.audio-content -->
        </div> <!--/.thumbnails -->
    <?php } ?>

    <div class="entry-content">
        <?php the_content(__('<br><br><span class="read-more-button">Read more <i class="fa fa-long-arrow-right"></i></span>', 'shaped_theme')); ?>

        <?php
            wp_link_pages( array(
                'before' => '<div class="page-links">' . __( 'Pages:', 'shaped_theme' ),
                'after'  => '</div>',
            ) );
        ?>
    </div><!-- .entry-content -->

</article><!-- #post-## -->

<div class="post-border"></div>