<?php global $st_options; ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
    </header> <!--/.entry-header -->

    <?php if ( 'post' == get_post_type() ) : ?>
    <div class="entry-meta">
        <?php st_posted_on(); ?>
    </div><!-- .entry-meta -->
    <?php endif; ?>
        
    <?php $slides = rwmb_meta('st_gallery_images','type=image_advanced'); ?>
    <?php $count = count($slides); ?>
    <?php if($count > 0): ?>
        <div class="thumbnails">
            <div id="blog-gallery-slider" class="carousel slide" data-ride="carousel">

                <!-- Wrapper for slides -->
                <div class="carousel-inner">

                    <?php $slide_no = 1; ?>

                    <?php foreach( $slides as $slide ): ?>
                        <div class="item <?php if($slide_no == 1){ echo 'active'; }; ?>">
                            <?php $images = wp_get_attachment_image_src( $slide['ID'], 'blog-thumb' ); ?>
                            <img src="<?php echo $images[0]; ?>" alt="">
                        </div>
                        <?php $slide_no++ ?>
                    <?php endforeach; ?>

                </div>

                <!-- Controls -->
                <a class="left carousel-control" href="#blog-gallery-slider" data-slide="prev">
                <i class="fa fa-long-arrow-left"></i>
                </a>
                <a class="right carousel-control" href="#blog-gallery-slider" data-slide="next">
                <i class="fa fa-long-arrow-right"></i>
                </a>
            </div>
        </div>
    <?php endif; ?>

    <div class="entry-content">
        <?php the_content(); ?>
    </div> <!-- //.entry-content -->

</article> <!--/#post-->

<?php if ($st_options['tags-show']) { ?>
    <div class="entry-tags"><?php the_tags('', '', ''); ?></div>
<?php } ?>

<br>

<?php if ($st_options['share-buttons-show']) { 
    get_template_part( 'inc/post-format/social-buttons' );
 } ?>

<?php if ($st_options['st-post-like']) { ?>
    <div class="pull-right st-post-like"><?php echo getPostLikeLink( get_the_ID() ); ?></div>
<?php } ?>
<div class="single-post-border"></div>