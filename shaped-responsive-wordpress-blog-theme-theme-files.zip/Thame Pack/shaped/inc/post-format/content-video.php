
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
    </header><!-- .entry-header -->
    
    <?php if ( 'post' == get_post_type() ) : ?>
    <div class="entry-meta">
        <?php st_posted_on(); ?>
    </div><!-- .entry-meta -->
    <?php endif; ?>

    <?php if (rwmb_meta( 'st_video_source' )) { ?>
        <div class="thumbnails">
            <div class="entry-video">
                <?php $video_source = rwmb_meta( 'st_video_source' ); ?>
                <?php $video = rwmb_meta( 'st_video' ); ?>

                <?php if($video_source == 1): ?>
                    <?php echo rwmb_meta( 'st_video' ); ?>
                <?php elseif ($video_source == 2): ?>
                    <?php echo '<iframe width="550" height="310" src="http://www.youtube.com/embed/'.$video.'?rel=0&showinfo=0&modestbranding=1&hd=1&autohide=1&color=white" frameborder="0" allowfullscreen></iframe>'; ?>
                <?php elseif ($video_source == 3): ?>
                    <?php echo '<iframe src="http://player.vimeo.com/video/'.$video.'?title=0&amp;byline=0&amp;portrait=0&amp;color=ffffff" width="550" height="310" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>'; ?>
                <?php endif; ?>
            </div>
        </div>
    <?php } ?>

    <div class="entry-content">
        <?php the_content(__('<br><br><span class="read-more-button">Read more <i class="fa fa-long-arrow-right"></i></span>', 'shaped_theme')); ?>

        <?php
            wp_link_pages( array(
                'before' => '<div class="page-links">' . __( 'Pages:', 'shaped_theme' ),
                'after'  => '</div>',
            ) );
        ?>
    </div><!-- .entry-content -->

</article><!-- #post-## -->

<div class="post-border"></div>