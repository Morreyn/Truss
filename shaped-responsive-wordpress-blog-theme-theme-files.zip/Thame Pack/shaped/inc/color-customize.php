<?php

if ( ! function_exists( 'st_color_theme' ) ) :

function st_color_theme(){?>
<?php global $st_options; ?>
	<style>
		.logo-carousel{
			background-image: url(<?php echo $st_options['featured-background'] ['url']; ?>);
		}
		.logo-carousel .overlay{
			background-color: <?php echo $st_options['featured-overlay'] ['rgba']; ?>;
		}

		button:hover,
		input[type="button"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		button:focus,
		input[type="button"]:focus,
		input[type="reset"]:focus,
		input[type="submit"]:focus,
		button:active,
		input[type="button"]:active,
		input[type="reset"]:active,
		input[type="submit"]:active,
		.user-profile .profile-heading ul.author-social-profile li a:hover,
		#respond input:focus[type="text"], 
		#respond input:focus[type="email"], 
		#respond input:focus[type="url"],
		#respond textarea:focus,
		#comments .comment-reply a:hover,
		.tagcloud a:hover,
		.widget .social-link ul li a:hover,
		.next-previous-posts .previous-post h2 a:hover,
		.next-previous-posts .next-post h2 a:hover,
		.pagination li a:focus, 
		.pagination li a:hover, 
		.pagination li span:focus, 
		.pagination li span.current, 
		.pagination li span:hover,
		.entry-tags a:hover,
		a:hover.more-link .read-more-button,
		.post-social-button ul li a:hover,
		.footer-social a:hover,
		input:focus[type="text"],
		input:focus[type="email"],
		textarea:focus
		{
			border-color: <?php echo $st_options['primary_theme_color'] ?>;
		}

		button:hover,
		input[type="button"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.user-profile .profile-heading ul.author-social-profile li a:hover,
		#comments .comment-reply a:hover,
		#blog-gallery-slider .carousel-control.left,
		#blog-gallery-slider .carousel-control.right,
		ul.menu ul a:hover,
		.menu ul ul a:hover,
		ul.cat-menu ul a:hover,
		.cat-menu ul ul a:hover,
		.tagcloud a:hover,
		.widget .social-link ul li a:hover,
		.next-previous-posts .previous-post h2 a:hover,
		.next-previous-posts .next-post h2 a:hover,
		.pagination li a:focus, 
		.pagination li a:hover, 
		.pagination li span:focus, 
		.pagination li span.current, 
		.pagination li span:hover,
		.entry-tags a:hover,
		a:hover.more-link .read-more-button,
		.post-social-button ul li a:hover,
		.scroll-up a,
		.scroll-up a:hover,
		.scroll-up a:active,
		.footer-social a:hover,
		.owl-theme .owl-controls .owl-page.active span, 
		.owl-theme .owl-controls.clickable .owl-page:hover span,
		#instafeed .owl-controls .owl-buttons div,
		button.mfp-arrow {
			background-color: <?php echo $st_options['primary_theme_color'] ?>;
		}

		
		.user-profile .profile-heading h3 a:hover,
		#comments .comment-author a:hover, 
		#respond .logged-in-as a:hover,
		.menu li.current-menu-item a, .menu li.current_page_item a, .menu li a:hover,
		.top-social a:hover,
		.top-search a:hover,
		#post-carousel .item .post-title ul li a,
		#post-carousel .item .post-title ul li a:hover,
		.cat-menu li.current-menu-item a, .cat-menu li.current_page_item a, .cat-menu li a:hover,
		.widget li a:hover,
		#wp-calendar tfoot a,
		.widget .latest-posts .entry-title a:hover,
		.entry-meta a:hover,
		article header.entry-header h1.entry-title a:hover,
		.copy-right-text a:hover,
		.next-previous-post a:hover{
			color: <?php echo $st_options['primary_theme_color'] ?>;
		}

		a{
			color: <?php echo $st_options['anchor_theme_color'] ?>;
		}

		a:hover,
		.top-search a.sactive{
			color: <?php echo $st_options['anchor_hover_theme_color'] ?>;
		}





	</style>
<?php
}
add_action('wp_head', 'st_color_theme');

endif;



if ( ! function_exists( 'st_custom_codes' ) ) :

function st_custom_codes(){?>

<?php global $st_options; ?>
	<style>
		<?php echo $st_options['st-custom-css'] ?>
	</style>

	<script type="text/javascript">
		<?php echo $st_options['st-custom-js'] ?>
	</script>
<?php
}
add_action('wp_footer', 'st_custom_codes');

endif;