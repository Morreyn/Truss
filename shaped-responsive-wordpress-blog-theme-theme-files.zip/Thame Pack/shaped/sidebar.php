<?php global $st_options; ?>
<?php

    $sidebar = is_null($st_options['blog-layout']) ? 'right-sidebar' : $st_options['blog-layout'];

    if ($sidebar == 'right-sidebar' and is_active_sidebar('st-blog-sidebar')) {
        ?>
        <div class="col-md-3 col-sm-4">
            <div class="primary-sidebar widget-area" role="complementary">
                <?php dynamic_sidebar('st-blog-sidebar'); ?>
            </div>
        </div>
    <?php
    } elseif ($sidebar == 'left-sidebar' and is_active_sidebar('st-blog-sidebar')) {
        ?>
        <div class="col-md-3 col-md-pull-9 col-sm-4 col-sm-pull-8">
            <div class="primary-sidebar widget-area" role="complementary">
                <?php dynamic_sidebar('st-blog-sidebar'); ?>
            </div>
        </div>
    <?php
    }