<?php get_header(); ?>
<?php global $st_options; ?>

	<div class="st-content">
		<div class="container">
			<div class="row">
				<?php
                    $sidebar = is_null($st_options['blog-layout']) ? 'right-sidebar' : $st_options['blog-layout'];

                    $grid_class = 'col-md-12';

                    if ($sidebar == 'right-sidebar') {

                        $grid_class = (is_active_sidebar('st-blog-sidebar'))
                            ? 'col-md-9 col-sm-8 margin-right-40'
                            : $grid_class;

                    } elseif ($sidebar == 'left-sidebar') {
                        $grid_class = (is_active_sidebar('st-blog-sidebar'))
                            ? 'col-md-9 col-md-push-3 col-sm-8 col-sm-push-4 margin-left-40'
                            : $grid_class;
                    }
                ?>

				<div class="<?php echo $grid_class ?>">
					
					<div id="primary" class="content-area">
						<main id="main" class="site-main" role="main">


						<?php if ( have_posts() ) : ?>

							<header class="search-header">
								<div class="search-title"><?php printf( __( 'Search Results <h1>%s</h1>', 'shaped_theme' ), '<span>' . get_search_query() . '</span>' ); ?></div>
							</header><!-- .page-header -->

								<?php while ( have_posts() ) : the_post(); ?>

									<?php get_template_part( 'content', 'search' ); ?>

								<?php endwhile; ?>

								<?php
								 // Posts Pagination
	                                if ($st_options['blog-page-nav']) {
	                                    st_posts_pagination();
	                                } else {
	                                    st_posts_navigation();
	                                }
								?>

							<?php else : ?>

								<?php get_template_part( 'content', 'none' ); ?>

							<?php endif; ?>

						</main><!-- #main -->
					</div><!-- #primary -->
				</div>
				<?php get_sidebar(); ?>
			</div>
		</div>
	</div>


<?php get_footer(); ?>
